import 'react-native-gesture-handler';
import * as React from 'react';
import { View, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { BottomTabBar } from '@react-navigation/bottom-tabs';
import Ionicons from 'react-native-vector-icons/Ionicons';


// import screen components
import NewsList from './NewsList';
import SearchScreen from './SearchScreen';
import NewsDetailScreen from './NewsDetailScreen';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

const App = () => {
    return (
        <NavigationContainer>
            <Tab.Navigator tabBar={(props) => <BottomTabBar {...props} />}>
                <Tab.Screen
                    name="News"
                    component={NewsList}
                    options={{
                        tabBarIcon: ({ color, size }) => (
                            <Ionicons name="newspaper-outline" color={color} size={size} />
                        ),
                    }}
                />
                <Tab.Screen
                    name="Search"
                    component={SearchScreen}
                    options={{
                        tabBarIcon: ({ color, size }) => (
                            <Ionicons name="search-outline" color={color} size={size} />
                        ),
                    }}
                />
            </Tab.Navigator>
        </NavigationContainer>
    );
};

// stack navigator for News screen
const NewsStackScreen = () => (
    <Stack.Navigator>
        <Stack.Screen name="News" component={NewsList} />
        <Stack.Screen name="NewsDetail" component={NewsDetailScreen} />
    </Stack.Navigator>
);

export default App;
