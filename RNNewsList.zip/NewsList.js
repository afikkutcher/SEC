import React, { useState, useEffect } from 'react';
import { View, FlatList, TouchableOpacity, StyleSheet, Text } from 'react-native';
import axios from 'axios';
import { useNavigation } from '@react-navigation/native';

// NewsList component displays a list of news headlines
// and allows the user to navigate to the NewsDetailScreen
// to read the full article
const NewsList = () => {
    const [articles, setArticles] = useState([]);
    const navigation = useNavigation();

    useEffect(() => {
        // Make a request to the news API to fetch the latest articles
        const fetchArticles = async () => {
            const result = await axios(
                'https://newsapi.org/v2/top-headlines?country=MY&apiKey=a769bb835fff430a904099f12381124a'
            );
            setArticles(result.data.articles);
        };
        fetchArticles();
    }, []);

    return (
        <View style={styles.container}>
            <FlatList
                data={articles}
                renderItem={({ item }) => (
                    <TouchableOpacity
                        onPress={() =>
                            navigation.navigate('NewsDetailScreen', {
                                item,
                            })
                        }
                    >
                        <View style={styles.item}>
                            <Text>{item.title}</Text>
                        </View>
                    </TouchableOpacity>
                )}
                keyExtractor={(item) => item.title}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    item: {
        padding: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#ccc',
    },
});

export default NewsList;
