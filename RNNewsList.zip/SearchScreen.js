// SearchScreen.js


import { VirtualizedList } from 'react-native';
import React, { useState } from 'react';
import { View, Text, TextInput, Button, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import axios from 'axios';
import { Linking } from 'react-native';

const SearchScreen = () => {
    // State to store the search query and search results
    const [query, setQuery] = useState('');
    const [results, setResults] = useState([]);

    // Function to handle the search button press
    const handleSearch = async () => {
        // Make a request to the news API using the search query as a parameter
        const result = await axios(
            `https://newsapi.org/v2/everything?q=${query}&language=en&sortBy=relevancy&apiKey=a769bb835fff430a904099f12381124a`
        );
        // Set the search results in state
        setResults(result.data.articles);
    };

    return (
        <View style={styles.container}>
            {/* Input field to enter the search query */}
            <TextInput
                style={styles.input}
                value={query}
                onChangeText={(text) => setQuery(text)}
                placeholder="Search for news in Malaysia"
            />
            {/* Button to submit the search */}
            <Button title="Search" onPress={handleSearch} />
            {/* Flat list to display the search results */}
            <FlatList
                data={results}
                renderItem={({ item }) => (
                    <TouchableOpacity onPress={() => Linking.openURL(item.url)}>
                        <View style={styles.item}>
                            <Text>{item.title}</Text>
                        </View>
                    </TouchableOpacity>
                )}
                keyExtractor={(item) => item.title}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    input: {
        width: '80%',
        height: 40,
        borderWidth: 1,
        borderColor: '#ccc',
        padding: 10,
        margin: 10,
    },
    item: {
        padding: 10,
        marginVertical: 8,
        marginHorizontal: 16,
    },
});

export default SearchScreen;
