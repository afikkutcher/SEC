<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <!--Metas-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Buku Gapo Bookstore - Over 30 million book titles are available and free e-books and library for your reading pleasure.">
    <title>BukuGapo</title>

    <!--External Stylesheets css-->
	
    <!-- jQuery -->
    <script src="./js/jquery-1.12.4.min.js"></script>
	

    <!-- Bootstrap -->
    <link rel="stylesheet" href="./css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!--Simple Line icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.5.5/css/simple-line-icons.min.css">

    <!--Animate -->
    <link rel="stylesheet" href="./css/animate.css">

    <!-- Owl-carousel-->
<!--    <link rel="stylesheet" href="./css/owl.carousel.min.css">-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

    <!-- Magnific Popup-->
    <link rel="stylesheet" href="./css/magnific-popup.css">



    <!--Stylesheets css-->
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/responsive.css">


    <!-- Google Fonts -->
    <link href="./css/googlefont.css" rel="stylesheet">


    <!-- Favicon -->
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link rel="icon" href="images/favicon.png" type="image/x-icon">

	<!-- Font Awesome Icon Library -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


</head>

<!--
	Web Layout: Based on Bootstrap 3, Block / Float. The reason Afik chose B3 was for the stability.
	This website layout is simple and easier to manage with float. No need to use Flex or Grid.

	From this point forward, it is about making the appearance of the page according to the expected flow, and CSS.

	Reference: Bootstrap 3 Documentation
-->

<body data-spy="scroll" data-target=".navbar-default" data-offset="100" style="">

    <!-- Page Preloader -->

    <div id="loading-page" style="display: none;">
        <div id="loading-center-page" style="display: none;">
            <div id="loading-center-absolute">

                <div class="loader"></div>
            </div>
        </div>

    </div>

    <!--header-->
    <!-- Afik got inspired by W3School Bootstrap example for data-spy affix method to make the header static and change attribute when scrolling
    this is the reference link: https://www.w3schools.com/bootstrap/tryit.asp?filename=trybs_scrollspy_affix&stacked=h -->

    <div class="navbar navbar-default navbar-fixed-top affix-top" role="navigation" data-spy="affix" data-offset-top="50">

        <div class="container">

            <!--Gapo navigation & logo-->

            <div class="navbar-header">

                <button type="button" class="navbar-toggle dropdown-button waves-effect waves-teal btn-flat" data-toggle="collapse" data-target="#navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>

            </button>

				
<!--
			Comments: In the navigation section, Afik made the navigation bar background colour to alternate
				when scrolling down, and the logo colour will change (inversely)
-->
            <a class="navbar-brand logo" href="index.php">

                <img src="images/gapo-light.png" class="logo-light" alt="" title="">
                <img src="images/gapo-dark.png" class="logo-dark" alt="" title="">


            </a>
        </div>

        <!--Links navigation menu-->
        <div class="navbar-collapse collapse" id="navbar-collapse">
            <ul class="nav navbar-nav navbar-right navigation-links">
                <li>
                    <a data-scroll="" href="index.php" class="section-scroll">Back to Gapo</a>
                </li>

                <li>
                    <a data-scroll="" href="browse.php" class="section-scroll">Browse </a>
                </li>
				<li>
				    <a data-scroll="" href="find.php" class="section-scroll">Find </a>
                </li>
                <li class="active-link active">
                    <a data-scroll="" href="#find" class="section-scroll">Preview </a>
                </li>

                
            </ul>
        </div>

    </div>

</div>
	
<!--	End of Navigation Block-->

	<!--Intro-->

<section id="home" class="intro-section">

    <div class="section-inner-intro xs-section-align sm-section-align">


        <!--container-->
        <div class="container">
            <div class="row">


                <div class="intro-section-content">
				
                    
                    <div class="col-sm-7 col-md-6 col-md-offset-1 text-inner">
						<div class="text-section">
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						
                            <h1>What it is all about?</h1>

                            <p>Here are the details.</p>
                            <p>&nbsp;</p>
							<p>&nbsp;</p>   
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!--container-->
    </section>

    <!--End intro-->

    <!--Preview-->

    
    <section id="preview" class="padd-section bg-color-section">


                                    <!--container-->

                                    <div class="container">
                                        <div class="row">


                                            <div class="col-xs-12 col-sm-6 col-md-6">

                                                <!-- Start title-section -->
                                                <div class="section-header">
                                                    <h4 onclick="location.href='find.php';" class="section-title text-left margin-40 ">Book Title</h4>
                                                    <p onclick="location.href='find.php';"> Summary
                                                    </p>
                                              </div>
                                                <!-- End title-section -->

                                                <div class="tabs-inner">

                                                    <!-- Nav tabs -->
                                                    <ul class="nav nav-tabs" role="tablist">
                                                        <li class="active"><a href="#tab1" role="tab" data-toggle="tab">Availability</a></li>
                                                        <li><a href="/#tab2" role="tab" data-toggle="tab">Review</a></li>

                                                        <li><a href="#tab3" role="tab" data-toggle="tab">Details</a></li>

                                                    </ul>

                                                    <!-- Tab panes -->
                                                    <div class="tab-content">
                                                        <div class="tab-pane active" id="tab1">
                                                        <h3>Best deals for you&nbsp;&nbsp;</h3>

                                                            

                                                            <p>
                                                            Amazon Book, Amazon Kindle, Book Depository, Shopee</p>


                                                        </div>


                                                        <div class="tab-pane" id="tab2">

                                                            <h3>What others say about this item?</h3>

                                                            

                                                            <p>
                                                                Stars & Reviews
                                                            </p>


                                                        </div>


                                                        <div class="tab-pane" id="tab3">

                                                            <h3>Book Details</h3>

                                                            

                                                            <p>
                                                                Author, Date, Description
                                                            </p>


                                                        </div>

                                                    </div>

                                                </div>

                                            </div>
                                            <div class="col-xs-12 col-md-6 col-sm-6">

                                                <div class="book-screen">
                                                    <img onclick="location.href='find.php';" class="book-above wow fadeInLeft" src="https://m.media-amazon.com/images/I/41DE1QUjacL.jpg" data-wow-delay=".4s" alt="" title="" style="visibility: hidden; animation-delay: 0.4s; animation-name: none;">
                                                    <img onclick="location.href='find.php';" class="book-beyond wow fadeInLeft" src="https://m.media-amazon.com/images/I/51qFqP094-L._SY346_.jpg" data-wow-delay=".8s" alt="" title="" style="visibility: hidden; animation-delay: 0.8s; animation-name: none;">
                                                </div>

                                            </div>

                                        </div>

                                        <!--container-->

                                    </div>

                                </section>

 

                        <!--Footer -->

                        <footer>

                            <div class="container">
                                <div class="row-centered">

                                    <div class="footer-top">

                                        <!-- Start title-section -->
                                        

                                                 </div>

                                                 <div class="footer-bottom">
                                                    <!-- COPYRIGHT TEXT -->
													 <a href="#"> Terms of Use & PDPA</a>

                                                    <div class="copyright">
                                                        <p>2022 © Copyright www.gapo.com.my All rights Reserved.</p>
                                                    </div>
                                                    <!-- COPYRIGHT TEXT -->


                                                </div>


                                            </div>
                                        </div>

									
                                    </footer>


                                    <!--Footer -->
									


                					<script src="./js/modernizr.js"></script>
                                    <!-- Bootstrap Plugins -->
                                    <script src="./js/bootstrap.min.js"></script>                    
	

	
	
	
	
	
									
                                    
                                    <!-- Plugins -->
                                    <script src="./js/jquery.easing.js"></script>
                                    <script src="./js/wow.min.js"></script>
                                    <script src="./js/owl.carousel.min.js"></script>
                                    <script src="./js/magnific-popup.min.js"></script>
                                    <script src="./js/jquery.scrollUp.min.js"></script>
                                    <script src="./js/jquery.ajaxchimp.min.js"></script>
                                    <!-- Main js -->
                                    <script src="./js/main.js"></script>
	
									


									
	
	
		<a id="scrollUp" href="#top" style="display: none; position: fixed; z-index: 2147483647;">
		<i class="icon-arrow-up"></i></a>
		
</body>
</html>
