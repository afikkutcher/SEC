<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <!--Metas-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Buku Gapo Bookstore - Over 30 million book titles are available and free e-books and library for your reading pleasure.">
    <title>BukuGapo</title>

    <!--External Stylesheets css-->
	
    <!-- jQuery -->
    <script src="./js/jquery-1.12.4.min.js"></script>
	

    <!-- Bootstrap -->
    <link rel="stylesheet" href="./css/bootstrap.min.css">

    <!--Simple Line icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.5.5/css/simple-line-icons.min.css">

    <!--Animate -->
    <link rel="stylesheet" href="./css/animate.css">

    <!-- Owl-carousel-->
<!--    <link rel="stylesheet" href="./css/owl.carousel.min.css">-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

    <!-- Magnific Popup-->
    <link rel="stylesheet" href="./css/magnific-popup.css">

    <!-- Buku Tarik-->
    <link rel="stylesheet" href="./css/bukuTarik.css">

    <!--Stylesheets css-->
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/responsive.css">


    <!-- Google Fonts -->
    <link href="./css/googlefont.css" rel="stylesheet">


    <!-- Favicon -->
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link rel="icon" href="images/favicon.png" type="image/x-icon">




</head>

<!--
	Web Layout: Based on Bootstrap 3, Block / Float. The reason Afik chose B3 was for the stability.
	This website layout is simple and easier to manage with float. No need to use Flex or Grid.

	From this point forward, it is about making the appearance of the page according to the expected flow, and CSS.

	Reference: Bootstrap 3 Documentation
-->

<body data-spy="scroll" data-target=".navbar-default" data-offset="100" style="">

    <!-- Page Preloader -->

    <div id="loading-page" style="display: none;">
        <div id="loading-center-page" style="display: none;">
            <div id="loading-center-absolute">

                <div class="loader"></div>
            </div>
        </div>

    </div>

    <!--header-->
    <!-- Afik got inspired by W3School Bootstrap example for data-spy affix method to make the header static and change attribute when scrolling
    this is the reference link: https://www.w3schools.com/bootstrap/tryit.asp?filename=trybs_scrollspy_affix&stacked=h -->

    <div class="navbar navbar-default navbar-fixed-top affix-top" role="navigation" data-spy="affix" data-offset-top="50">

        <div class="container">

            <!--Gapo navigation & logo-->

            <div class="navbar-header">

                <button type="button" class="navbar-toggle dropdown-button waves-effect waves-teal btn-flat" data-toggle="collapse" data-target="#navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>

            </button>

				
<!--
			Comments: In the navigation section, Afik made the navigation bar background colour to alternate
				when scrolling down, and the logo colour will change (inversely)
-->
            <a class="navbar-brand logo" href="#">

                <img src="images/gapo-light.png" class="logo-light" alt="" title="">
                <img src="images/gapo-dark.png" class="logo-dark" alt="" title="">


            </a>
        </div>

        <!--Links navigation menu-->
        <div class="navbar-collapse collapse" id="navbar-collapse">
            <ul class="nav navbar-nav navbar-right navigation-links">
                <li class="active-link active">
                    <a data-scroll="" href="#home" class="section-scroll">Home</a>
                </li>

                <li>
                    <a data-scroll="" href="#browse" class="section-scroll">Browse </a>
                </li>
                <li>
                    <a data-scroll="" href="#find" class="section-scroll">Find </a>
                </li>

                <li>
                    <a data-scroll="" href="#highlights" class="section-scroll"> Highlights </a>
                </li>
                <li>
                    <a data-scroll="" href="#offer" class="section-scroll">Offer</a>
                </li>
                <li>
                    <a data-scroll="" href="#preloved" class="section-scroll">Pre-Loved </a>
                </li>

                <li>
                    <a data-scroll="" href="#ebooks" class="section-scroll">E-Books </a>
                </li>

                <li>
                    <a data-scroll="" href="#shop" class="section-scroll">Shop</a>
                </li>
				
				<li>
                    <a data-scroll="" href="shop2.php" class="section-scroll"><i class="icon-login"></i></a>
                </li>


            </ul>
        </div>

    </div>

</div>
	
<!--	End of Navigation Block-->
	
	
	
<!--Intro-->

<section id="home" class="intro-section">

    <div class="section-inner-intro xs-section-align sm-section-align">


        <!--container-->
        <div class="container">
            <div class="row">


                <div class="intro-section-content">

                    <div class="col-sm-5 col-md-4">

                        <img src="./images/bookstore1.png" style="border-radius:20px" class="img-responsive hidden-xl" title="" alt="Gapo Bookstore Image">

                    </div>


                    <div class="col-sm-7 col-md-6 col-md-offset-1 text-inner">
                        <div class="text-section">
                            <h1>We have over 30 million book titles available.</h1>

                            <p>How can we help you today?</p>
                                <a data-scroll href="#browse" class="btn btn-lg btn-link section-scroll"> Browse</a>
                                <a style="color:transparent;>||| "></a>
								<a href="#find" class="btn btn-lg btn-link section-scroll"> Find</a>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!--container-->
    </section>

    <!--End intro-->


    <!--browse-->

    <section id="browse" class="padd-section ">

        <!--Container // Kotak utama masukkan section atas ni. Make sure tutup bracket DIV-->

        <div class="container">
            <div class="row">
                <!-- START Section - First part call section header dan text center -->
                <div class="section-header text-center">
                    <div class="row-centered">
                        <div class="col-md-6 col-xs-12 col-sm-6 col-centered">

                            <h2 class="section-title text-center">Browse</h2>
                            <p>Click on one of the following categories to view a list of chosen books for quick browsing.
                            </p>
                            </div>
                        </div>
                    </div>
                    <!-- End title-section -->

                    <!-- Start Feature 1 -->

                    <div class="col-md-4 col-sm-4 col-xs-12 wow fadeInUp" style="visibility: hidden; animation-name: none;">

                        <div class="browse-block">

                            <i class="icon-heart"></i>
                            <h3>In Demand</h3>
                            <a href="browse.php">Best Sellers | Best Debuts | Top 20 | Biographies | Business & Leadership
                              | Children's Books | Cookbooks | History | Romance | Science Fiction</a>
                            </div>


                        </div>

                        <!-- End Feature 1 -->

                        <!-- Start Feature 2 -->
                        <div class="col-md-4 col-sm-4 col-xs-12 wow fadeInUp" style="visibility: hidden; animation-name: none;">

                            <div class="browse-block">

                                <i class="icon-mustache"></i>
                                <h3>Men's</h3>
                                <a href="browse.php">Sex | Self-Help | Sports & Outdoors | Business | Money | Politics
                                  | Games | Tools & Home Improvement | Men Lifestyle | Health & Style</a>

                                </div>


                            </div>

                            <!-- End Feature 2 -->
                            <!-- Start Feature 3 -->
                            <div class="col-md-4 col-sm-4 col-xs-12 wow fadeInUp" style="visibility: hidden; animation-name: none;">

                                <div class="browse-block">

                                    <i class="icon-diamond"></i>
                                    <h3>Women's</h3>
                                    <a href="browse.php">Romance  | Mystery, Thriller and Crime  |  Cookbooks  |  Health & Wellness
                                      |  Religion & Spirituality  | Fantasy | Fashion  | Style  | Furniture & Decoration  | Pets</a>

                                    </div>


                                </div>
                                <!-- End Feature 3 -->
				
                                <!-- Start Feature 4 -->
                                <div class="col-md-4 col-sm-4 col-xs-12 wow fadeInUp" style="visibility: hidden; animation-name: none;">

                                    <div class="browse-block">

                                        <i class="icon-settings"></i>
                                        <h3>They Move </h3>
                                        <a href="browse.php">Repair & Maintenance  |  Motorcycles  | Trucks & Vans  |  Classic Cars  |  History  |  Driver's Education  |
                                        Buyer's Guides  |  Racing  |  Luxury  |  Insurance </a>

                                        </div>
                                    </div>
                                    <!-- End Feature 4 -->

                                    <!-- Start Feature 5 -->
                                    <div class="col-md-4 col-sm-4 col-xs-12 wow fadeInUp" style="visibility: hidden; animation-name: none;">

                                        <div class="browse-block">

                                            <i class="icon-book-open"></i>
                                            <h3>Digital</h3>
                                            <a href="browse.php">Robotics  |  AI  | Digital Business  | Digital Products  | Machine Learning  | Software Engineering |  Networking  |
                                            Programming  |  UX  |  UI | NFT & Cryptos  | Digital Arts </a>

                                            </div>
                                        </div>
                                        <!-- End Feature 5 -->

                                        <!-- Start Feature 5 -->
                                        <div class="col-md-4 col-sm-4 col-xs-12 wow fadeInUp" style="visibility: hidden; animation-name: none;">

                                            <div class="browse-block">

                                                <i class="icon-note"></i>
                                                <h3>Children's</h3>
                                                <a href="browse.php">Picture Books  |  Easy Reader  |  Classical |  Fantasy  |  Sci-Fi  |  Toddlers </a>

                                                </div>
                                            </div>
                                            <!-- End Feature 5 -->
                                        </div>

                                    </div>
                                    <!--container-->

                                </section>

                                <!--End browse-->

                                <!--Find-->


                                <section id="find" class="padd-section bg-color-section">


                                    <!--container-->

                                    <div class="container">
                                        <div class="row">


                                            <div class="col-xs-12 col-sm-6 col-md-6">

                                                <!-- Start title-section -->
                                                <div class="section-header">
                                                    <h2 onclick="location.href='find.php';" class="section-title text-left margin-40 ">Want to FIND something specific?</h2>
                                                    <p onclick="location.href='find.php';"> Join for FREE and enjoy searching for available books on sale and a wide range of FREE E-Books. You also get to borrow books from established online libraries.
                                                    </p>
                                              </div>
                                                <!-- End title-section -->

                                                <div class="tabs-inner">

                                                    <!-- Nav tabs -->
                                                    <ul class="nav nav-tabs" role="tablist">
                                                        <li class="active"><a href="#tab1" role="tab" data-toggle="tab">Why Register?</a></li>
                                                        <li><a href="/#tab2" role="tab" data-toggle="tab">What's Inside</a></li>

                                                        <li><a href="#tab3" role="tab" data-toggle="tab">What you get?</a></li>

                                                    </ul>

                                                    <!-- Tab panes -->
                                                    <div class="tab-content">
                                                        <div class="tab-pane active" id="tab1">
                                                        <h3>Get a free account&nbsp;&nbsp;</h3>

                                                            <span class="number-tabs">01</span>

                                                            <p>
                                                            This is the key to access our members only section.&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </p>


                                                        </div>


                                                        <div class="tab-pane" id="tab2">

                                                            <h3>30 Million Books!</h3>

                                                            <span class="number-tabs">02</span>

                                                            <p>
                                                                So many to choose from, so we help you to look for the best find, and you also get a free access to online libraries.
                                                            </p>


                                                        </div>


                                                        <div class="tab-pane" id="tab3">

                                                            <h3>You get lucky!</h3>

                                                            <span class="number-tabs">03</span>

                                                            <p>
                                                                Save time and money because we make your journey more efficient and fun. Plus you get new ideas from our suggested list.
                                                            </p>


                                                        </div>

                                                    </div>

                                                </div>

                                            </div>
                                            <div class="col-xs-12 col-md-6 col-sm-6">

                                                <div class="book-screen">
                                                    <img onclick="location.href='find.php';" class="book-above wow fadeInLeft" src="images/BookAnimate2.png" data-wow-delay=".4s" alt="" title="" style="visibility: hidden; animation-delay: 0.4s; animation-name: none;">
                                                    <img onclick="location.href='find.php';" class="book-beyond wow fadeInLeft" src="images/BookAnimate1.png" data-wow-delay=".8s" alt="" title="" style="visibility: hidden; animation-delay: 0.8s; animation-name: none;">
                                                </div>

                                            </div>

                                        </div>

                                        <!--container-->

                                    </div>

                                </section>
                                <!--End Find-->



                                <!--Details Find-->


                                <section id="app-about" class="padd-section">


                                    <!--container-->

                                    <div class="container">
                                        <div class="row">

                                         <div class="col-xs-12 col-md-6 col-sm-6">

                                            <div class="book-screen">

                                                <img onclick="location.href='find.php';" class="book-beyond app-book-1 wow fadeInLeft" src="images/BookAnimate4.png" data-wow-delay=".8s" alt="" title="" style="visibility: hidden; animation-delay: 0.8s; animation-name: none;">
                                                <img onclick="location.href='find.php';" class="book-above app-book-2 wow fadeInLeft" src="images/BookAnimate3.png" data-wow-delay=".4s" alt="" title="" style="visibility: hidden; animation-delay: 0.4s; animation-name: none;">

                                            </div>

                                        </div>


                                        <div class="col-xs-12 col-sm-6 col-md-6">

                                            <!-- Start title-section -->

                                            <h2 onclick="location.href='find.php';" class="section-title text-left margin-40">What to find?&nbsp;</h2>

                                            <!-- End title-section -->

                                            <div class="app-text mb-30">
                                                <p>We make searching easier. It begins with a suggested list of popular categories and items, and then a refined search based on your preferences .&nbsp; &nbsp; </p>

                                            </div>
                                            <div class="row">

                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <div class="icon-box">

                                                        <div class="icon-box-icon">
                                                            <i class="icon-trophy"></i>
                                                        </div>

                                                        <div class="icon-box-content">
                                                           <h3>Popular Categories</h3>
                                                           <p>Worldwide &amp; Local Top Categories&nbsp; </p>
                                                       </div>

                                                   </div>


                                               </div>

                                               <div class="col-md-6 col-sm-6 col-xs-12">
                                                <div class="icon-box">

                                                    <div class="icon-box-icon">
                                                        <i class="icon-book-open"></i>
                                                    </div>

                                                    <div class="icon-box-content">
                                                       <h3>E-Books &amp; Gratis &nbsp; &nbsp;&nbsp;</h3>
                                                       <p>Digital format goes a long way&nbsp; &nbsp; </p>
                                                   </div>

                                               </div>


                                           </div>

                                           <div class="col-md-6 col-sm-6 col-xs-12">
                                            <div class="icon-box">

                                                <div class="icon-box-icon">
                                                    <i class="icon-fire"></i>
                                                </div>

                                                <div class="icon-box-content">
                                                   <h3>Hot Items on Sale&nbsp;</h3>
                                                   <p>Offers and discounts in your country and abroad. </p>
                                               </div>

                                           </div>


                                       </div>

                                       <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="icon-box">

                                            <div class="icon-box-icon">
                                              <i class="icon-bulb"></i>
                                            </div>

                                            <div class="icon-box-content">
                                               <h3>New Ideas&nbsp;</h3>
                                               <p>Don't know what to find or what to buy? We have new ideas. </p>
                                           </div>

                                       </div>


                                   </div>
                               </div>





                           </div>


                       </div>

                       <!--container-->

                   </div>

               </section>
               <!--End Find Details-->



               <!--Highlights-->


               <section id="highlights" class="padd-section bg-color-blue ">

                <!--container-->

                <div class="container">
                    <div class="row">

                        <!-- Start title-section -->
                        <div class="row-centered white-text">
                          <div class="col-md-6 col-xs-12 col-sm-6 col-centered">

                            <h2 class="section-title text-center white-text">Highlights</h2>
                              <p>Click on the book to go to an external merchant site &nbsp; &nbsp;&nbsp;</p>
                            </div>
                        </div>
					</div>
					<div class="buku-tarik-grid col-md-12">
                              <a href="https://www.amazon.com/Kindle-Store-Colleen-Hoover/s?rh=n%3A133140011%2Cp_27%3AColleen+Hoover" class="buku-tarik article" style="background: url('./books/Top1.jpg') center center; background-size: cover;">
                              </a>

                              <a href="https://www.amazon.com/Books-Delia-Owens/s?rh=n%3A283155%2Cp_27%3ADelia+Owens" class="buku-tarik" style="background: url('./books/Top2.jpg') center center; background-size: cover;">
                              </a>

                              <a href="https://www.bookdepository.com/Verity-Colleen-Hoover/9781538739723" class="buku-tarik" style="background: url('./books/Top3.jpg') center center; background-size: cover;">
                              </a>

                              <a href="https://www.bookdepository.com/Atomic-Habits-James-Clear/9781847941831?ref=grid-view&qid=1665588528318&sr=1-1" class="buku-tarik" style="background: url('./books/Top4.jpg') center center; background-size: cover;">
                              </a>

							  <a href="https://www.bookdepository.com/Reminders-Him-Colleen-Hoover/9781542025607?ref=grid-view&qid=1665588586810&sr=1-1" class="buku-tarik article" style="background: url('./books/Top5.jpg') center center; background-size: cover;">
                              </a>

                              <a href="https://www.bookdepository.com/Ugly-Love/9781471136726" class="buku-tarik" style="background: url('./books/Top6.jpg') center center; background-size: cover;">
                              </a>

                              <a href="https://www.bookdepository.com/Seven-Husbands-Evelyn-Hugo-Taylor-Jenkins-Reid/9781398515697?ref=grid-view&qid=1665588659552&sr=1-1" class="buku-tarik" style="background: url('./books/Top7.jpg') center center; background-size: cover;">
                              </a>

                              <a href="https://www.amazon.com/Body-Keeps-Score-Healing-Trauma/dp/0143127748" class="buku-tarik" style="background: url('./books/Top8.jpg') center center; background-size: cover;">
                              </a>
						
							  <a href="https://www.amazon.com/48-Laws-Power-Robert-Greene/dp/0140280197" class="buku-tarik article" style="background: url('./books/Top9.jpg') center center; background-size: cover;">
                              </a>

                              <a href="https://www.amazon.com/Four-Agreements-Practical-Personal-Freedom/dp/1878424319" class="buku-tarik" style="background: url('./books/Top10.jpg') center center; background-size: cover;">
                              </a>

                              <a href="https://www.amazon.com/Very-Hungry-Caterpillar-Eric-Carle/dp/0399226907" class="buku-tarik" style="background: url('./books/Top11.jpg') center center; background-size: cover;">
                              </a>

                              <a href="https://www.amazon.com/I-Love-You-Moon-Back/dp/1589255518/" class="buku-tarik" style="background: url('./books/Top12.jpg') center center; background-size: cover;">
                              </a>
                            </div>
				</div>
				   
				   
				   
				</section>	
						
				


       




                <!--End Highlights-->


                <!--Offer-->

                <section id="offer" class="padd-section ">


                    <!--container-->

                    <div class="container">
                        <div class="row">
                            <!-- Start title-section -->
                            <div class="section-header">
                                <div class="row-centered">
                                    <div class="col-md-6 col-xs-12 col-sm-6 col-centered">

                                        <h2 class="section-title text-center">Free & Best Offers</h2>
                                        <p>100% Free E-Books and the surprise boxes are just awesome</p>
                                        </div>
                                    </div>
                                </div>
                                <!-- End title-section -->

                                <div class="plan-price  text-center clearfix">


                                    <div class="col-xs-12 col-sm-4 wow fadeInLeft" style="visibility: hidden; animation-name: none;">
                                        <div class="plan-featured">

                                            <div class="header-plan text-center">
                                                <i class="icon-support"></i>
                                                <h3>Free Books</h3>
                                            </div>

                                            <div class="content-plan">
                                                <ul>
                                                    <li>Online Books</li>
                                                    <li>E Books</li>
                                                    <li>Articles</li>
                                                    <li>Magazines</li>
                                                </ul>

                                                <div class="price-content">

                                                    <sup>$</sup>0<sub>/ month</sub>
                                                </div>

                                            </div>

                                            <div class="footer-plan">
                                                <a href="https://www.free-ebooks.net" class="btn btn-md btn-outline text-uppercase">&nbsp;ACCESS</a>

                                            </div>
                                        </div>
                                    </div>
                                    

									<div class="col-xs-12 col-sm-4 wow fadeInLeft" style="visibility: hidden; animation-name: none;">
                                        <div class="plan-featured text-center">

                                            <div class="header-plan">
                                                <i class="icon-briefcase"></i>
                                                <h3>BookBrews Box</h3>
                                            </div>

                                            <div class="content-plan">
                                                <ul>
                                                    <li>A box with book of your </li>
                                                    <li>favorite genres, tea or </li>
                                                    <li>coffee, and high quality </li>
                                                    <li>chocolate.</li>
                                                </ul>
                                                <div class="price-content">

                                                    <sup>$</sup>43.33<sub>/ month</sub>
                                                </div>
                                            </div>

                                            <div class="footer-plan">
                                                <a href="https://www.cratejoy.com/subscription-box/bookbrews/?pt=category&gs=book-subscription-boxes&cn=8&pn=2&ft=&sn=main"class="btn btn-md btn-outline text-uppercase">ACCESS</a>

                                            </div>
                                        </div>
                                    </div>
									
                                    <div class="col-xs-12 col-sm-4 wow fadeInLeft" style="visibility: hidden; animation-name: none;">
                                        <div class="plan-featured text-center">

                                            <div class="header-plan">
                                                <i class="icon-briefcase"></i>
                                                <h3>Self Care Box</h3>
                                            </div>

                                            <div class="content-plan">
                                                <ul>
                                                    <li>Self care is so important, </li>
                                                    <li>but it can be hard to find </li>
                                                    <li>the time to focus on taking </li>
                                                    <li>care of yourself.</li>
                                                </ul>
                                                <div class="price-content">

                                                    <sup>$</sup>35<sub>/ month</sub>
                                                </div>
                                            </div>

                                            <div class="footer-plan">
                                                <a href="https://www.cratejoy.com/subscription-box/muse-illuminate1/?pt=category&gs=book-subscription-boxes&cn=18&pn=2&ft=&sn=main" class="btn btn-md btn-outline text-uppercase">ACCESS</a>

                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <!--container-->

                        </div>

                    </section>
                    <!--End offer-->
					
                    <!--Preloved -->


                    <section id="preloved" class="padd-section bg-color-blue ">

                        <!--container-->

                        <div class="container">
                            <div class="row">

                                <!-- Start title-section -->

                                <div class="row-centered white-text">
                                    <div class="col-md-6 col-xs-12 col-sm-6 col-centered">

                                        <h2 class="section-title text-center white-text">Pre-Loved</h2>
                                        <p>From rare books to signed copies, they are priceless.</p>
																			
                                        </div>
                                 </div>


                                    <div class="row-centered ">
										<div></div>
										<div></div>
                                        <div class="col-md-7 col-xs-12 col-sm-7 col-centered wow fadeInUp" style="visibility: hidden; animation-name: none;">
										
											<div class="owl-carousel owl-theme" >
												
        										<div class="item"><img src="https://m.media-amazon.com/images/I/71Dax2X6RhL._AC_UY327_FMwebp_QL65_.jpg"></div>
												
        										<div class="item"><img src="https://m.media-amazon.com/images/I/81HE+JDes-L._AC_UY327_FMwebp_QL65_.jpg"></div>
												
        										<div class="item"><img src="https://m.media-amazon.com/images/I/91tQkOHvW9L._AC_UY327_FMwebp_QL65_.jpg"></div>
												
												<div class="item"><img src="https://m.media-amazon.com/images/I/61clZgj1xZL._AC_UY327_FMwebp_QL65_.jpg"></div>
												
												<div class="item"><img src="https://m.media-amazon.com/images/I/71RIWM0sv6L._AC_UY327_FMwebp_QL65_.jpg"></div>
											
												<div class="item"><img src="https://m.media-amazon.com/images/I/91xsywxYsnL._AC_UY327_FMwebp_QL65_.jpg"></div>
												
        										<div class="item"><img src="https://m.media-amazon.com/images/I/81HE+JDes-L._AC_UY327_FMwebp_QL65_.jpg"></div>
												
        										<div class="item"><img src="https://m.media-amazon.com/images/I/71W7cGUIo0L._AC_UY327_FMwebp_QL65_.jpg"></div>
												
												<div class="item"><img src="https://m.media-amazon.com/images/I/71sifGleAWL._AC_UY327_FMwebp_QL65_.jpg"></div>
												
												<div class="item"><img src="https://m.media-amazon.com/images/I/71dDj1W87kL._AC_UY327_FMwebp_QL65_.jpg"></div>
												
												
    										</div>
											<div class="col-md-7 col-xs-12 col-sm-7 col-centered wow fadeInUp" style="visibility: hidden; animation-name: none;">
												
											</div>
											<div class="owl-carousel owl-theme">
        										<div class="item"><img src="https://m.media-amazon.com/images/I/61NdJMwAThS._AC_UY327_FMwebp_QL65_.jpg"></div>
												
        										<div class="item"><img src="https://m.media-amazon.com/images/I/9136kXA1i-L._AC_UY327_FMwebp_QL65_.jpg"></div>
												
        										<div class="item"><img src="https://m.media-amazon.com/images/I/81+UqGCKfRL._AC_UY327_FMwebp_QL65_.jpg"></div>
												
												<div class="item"><img src="https://m.media-amazon.com/images/I/61xkvfPVupL._AC_UY327_FMwebp_QL65_.jpg"></div>
												
												<div class="item"><img src="https://m.media-amazon.com/images/I/611oufwi3YL._AC_UY327_FMwebp_QL65_.jpg"></div>
												
												<div class="item"><img src="https://m.media-amazon.com/images/I/71-uDwQUDXL._AC_UY327_FMwebp_QL65_.jpg"></div>
												
        										<div class="item"><img src="https://m.media-amazon.com/images/I/61Bdp7XZhDL._AC_UY327_QL65_.jpg"></div>
												
        										<div class="item"><img src="https://m.media-amazon.com/images/I/71xD1Mog4AL._AC_UY327_QL65_.jpg"></div>
												
												<div class="item"><img src="https://m.media-amazon.com/images/I/71NNrCfueGL._AC_UY327_QL65_.jpg"></div>
												
												<div class="item"><img src="https://m.media-amazon.com/images/I/71lwvQIGI8L._AC_UY327_QL65_.jpg"></div>
												
    										</div>
                                            
                                        </div>
                                    </div>
								<div class="row-centered ">
								<a href="https://booksnbobs.com/" class="btn btn-lg btn-link section-scroll"> Pre-Love Items</a>
								</div>
								
								
							</div>	<!--row div ends-->	
							</div>  <!--container div ends-->
                        </section> <!--section ends-->

	
	
                        <!--End of Preloved -->


                        <!--E-Books -->

                        <section id="ebooks" class="padd-section bg-color-section">


                            <!--container-->

                            <div class="container">
                                <div class="row">

                                    <div class="section-header">
                                        <div class="row-centered">
                                            <div class="col-md-6 col-xs-12 col-sm-6 col-centered">

                                                <h2 class="section-title text-center">E-Books & Library</h2>
                                                <p>We also love free stuffs, so we share them with you.</p>
												<h4>These are external links, but they are FREE!</h4>
												<p>You gonna love them, so many choices.</p>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-3 col-sm-3 col-xs-12">
                                         <div class="offer-member member-image-hover">
                                         <img src="./books/overdrive.png" alt="Overdrive">
                                             <div class="member-caption">

                                                 <div class="member-content text-center">
                                                    <div class="member-content-inner" onclick="location.href='ebooks.php'">
                                                       <h4 class="member-title">OverDrive</h4>
                                                      <p class="member-subtitle">Free E-Books & Audio Books</p>
                                                     <ul class="member-icons">
                                                        <li class="social-icon"><a href="http://www.overdrive.com"><i class="icon-link"></i></a></li>
<!--
                                                        <li class="social-icon"><a href="#"><i class="icon-lock"></i></a></li>
                                                        <li class="social-icon"><a href="#"><i class="icon-star"></i></a></li>
-->
                                                    </ul>
                                                </div>
                                            </div>

                                        </div>

                                    </div>

                                </div>
                                     <div class="col-md-3 col-sm-3 col-xs-12">
                                         <div class="offer-member member-image-hover">
                                         <img src="./books/LibGen.png" alt="LibraryGen">
                                             <div class="member-caption">

                                                 <div class="member-content text-center">
                                                    <div class="member-content-inner" onclick="location.href='ebooks.php'">
                                                      <h4 class="member-title">Library Genesis</h4>
                                                      <p class="member-subtitle">Free Library</p>
                                                      <ul class="member-icons">
                                                        <li class="social-icon"><a href="http://www.libgen.is"><i class="icon-link"></i></a></li>
<!--
                                                        <li class="social-icon"><a href="#"><i class="icon-lock"></i></a></li>
                                                        <li class="social-icon"><a href="#"><i class="icon-star"></i></a></li>
-->
                                                    </ul>
                                                </div>
                                            </div>

                                        </div>

                                    </div>

                                </div>

                                     <div class="col-md-3 col-sm-3 col-xs-12">
                                         <div class="offer-member member-image-hover">
                                         <img src="./books/feedbooks.jpg" alt="Feedbooks">
                                             <div class="member-caption">

                                                 <div class="member-content text-center">
                                                    <div class="member-content-inner" onclick="location.href='ebooks.php'">
                                                      <h4 class="member-title">FeedBooks</h4>
                                                      <p class="member-subtitle">Freebies</p>
                                                      <ul class="member-icons">
                                                        <li class="social-icon"><a href="http://www.feedbooks.com"><i class="icon-link"></i></a></li>
<!--
                                                        <li class="social-icon"><a href="#"><i class="icon-lock"></i></a></li>
                                                        <li class="social-icon"><a href="#"><i class="icon-star"></i></a></li>
-->
                                                    </ul>
                                                </div>
                                            </div>

                                        </div>

                                    </div>

                                </div>

                                     <div class="col-md-3 col-sm-3 col-xs-12">
                                         <div class="offer-member member-image-hover">
                                         <img src="./books/manybooks.jpg" alt="Manybooks">
                                             <div class="member-caption">

                                                 <div class="member-content text-center">
                                                    <div class="member-content-inner" onclick="location.href='ebooks.php'">
                                                      <h4 class="member-title">ManyBooks</h4>
                                                      <p class="member-subtitle">The name says it all</p>
                                                      <ul class="member-icons">
                                                        <li class="social-icon"><a href="http://www.manybooks.net"><i class="icon-link"></i></a></li>
<!--
                                                        <li class="social-icon"><a href="#"><i class="icon-lockr"></i></a></li>
                                                        <li class="social-icon"><a href="#"><i class="icon-star"></i></a></li>
-->
                                                    </ul>
                                                </div>
                                            </div>

                                        </div>

                                    </div>

                                </div>





                            </div>
                        </div>
                    </section>

                    <!--End of E-Books & Library -->


                    <!--Shop -->

                    <section id="shop" class="padd-section padd-bottom">

                        <!--container-->
                        <div class="container">
                            <div class="row">

                                <!-- Start title-section -->
                                <div class="row-centered">
                                    <div class="col-md-6 col-xs-12 col-sm-6 col-centered ">

                                        <div class="shop-content">
                                            <h2>Getting the best deal&nbsp;&nbsp;</h2>
                                            <h3>The best titles, value for money&nbsp;</h3>
                                            <p>We have many books, articles and items that will make you happy. It does not matter whether you just want to browse and have a read, or get a book delivered at your doorstep, we will make it happen.&nbsp; &nbsp;&nbsp;</p>

                                                <div class="btn-shop-content">

                                                    <a data-scroll href="shop2.php" class="btn btn-lg btn-link section-scroll"> Enter</a>
                                					
                                                </div>


                                            <p> <img src="https://cdn.tatlerasia.com/asiatatler/i/hk/2021/02/22120006-89854234-2560114784256002-1476840033916152876-n_cover_1080x720.jpg" alt="" title=""> </p>
                                                <p>&nbsp;</p>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <!--End Shop  -->

                        <!--Footer -->

                        <footer>

                            <div class="container">
                                <div class="row">
								<div class="row-centered">	
                                    <div class="footer-top">
										
                                        <!-- Start title-section -->
<!--										<p>Can't find what you are looking for? Let's search now.</p>-->

                                                                <!-- Search -->
										
										
														<div class="col-md-6 col-xs-12 col-sm-6 col-centered ">
														
															<a data-scroll href="find.php" class="btn btn-lg btn-link section-scroll"> Intuitive Search</a>
<!--
															<script async src="https://cse.google.com/cse.js?cx=e6987224277c5416b">
														</script>
										<div class="gcse-search"></div>
-->
<!--
                                                                <div class="search-form">

                                                                    <form action="#" method="post" class="search-text" novalidate="true">
                                                                        <div class="input-group">
                                                                            <input type="text" class="form-control text-input" placeholder="Let us know what you want to find" name="searchfield">
                                                                            <span class="input-group-addon">
                                                                             <input type="submit" class="btn btn-search" value="Search">
                                                                         </span>


                                                                     </div>
                                                                     <p class="error-message"></p>
                                                                     <p class="sucess-message"></p>

                                                                 </form>
                                                             </div>
-->
							

	
                                                 </div>
									

										</div>
									
                                                 <div class="footer-bottom">
                                                    <!-- COPYRIGHT TEXT -->
													 <a href="#"> Terms of Use & PDPA</a>

                                                    <div class="copyright">
                                                        <p>2022 © Copyright www.gapo.com.my All rights Reserved.</p>
                                                    </div>
                                                    <!-- COPYRIGHT TEXT -->


                                                </div>


                                            </div>
                                        </div>

							</div>
                                    </footer>


                                    <!--Footer -->
									


                					<script src="./js/modernizr.js"></script>
                                    <!-- Bootstrap Plugins -->
                                    <script src="./js/bootstrap.min.js"></script>                    
	

	
	
	
	
	
									
                                    
                                    <!-- Plugins -->
                                    <script src="./js/jquery.easing.js"></script>
                                    <script src="./js/wow.min.js"></script>
                                    <script src="./js/owl.carousel.min.js"></script>
                                    <script src="./js/magnific-popup.min.js"></script>
                                    <script src="./js/jquery.scrollUp.min.js"></script>
                                    <script src="./js/jquery.ajaxchimp.min.js"></script>
                                    <!-- Main js -->
                                    <script src="./js/main.js"></script>
	
									
<!--                  //Owl-Caroussel New Items Added Here - Afik 26 Sept for Preloved Section-->

									<script>
										$(document).ready(function(){
										$('.owl-carousel').owlCarousel({
											loop:true,
											margin:10,
											nav:false,
											responsive:{
											0:{
											items:1
											},
											600:{
											items:3
											},
											1000:{
											items:5
											}
										}
										})
										});
									</script>                  
	
	
	
		<a id="scrollUp" href="#top" style="display: none; position: fixed; z-index: 2147483647;">
		<i class="icon-arrow-up"></i></a>
		
</body>
</html>
