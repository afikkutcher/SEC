<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <!--Metas-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Buku Gapo Bookstore - Over 30 million book titles are available and free e-books and library for your reading pleasure.">
    <title>BukuGapo</title>

    <!--External Stylesheets css-->
	
    <!-- jQuery -->
    <script src="./js/jquery-1.12.4.min.js"></script>
	

    <!-- Bootstrap -->
    <link rel="stylesheet" href="./css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!--Simple Line icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.5.5/css/simple-line-icons.min.css">

    <!--Animate -->
    <link rel="stylesheet" href="./css/animate.css">

    <!-- Owl-carousel-->
<!--    <link rel="stylesheet" href="./css/owl.carousel.min.css">-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

    <!-- Magnific Popup-->
    <link rel="stylesheet" href="./css/magnific-popup.css">

    <!-- Buku Tarik-->
    <link rel="stylesheet" href="./css/bukuTarik.css">

    <!--Stylesheets css-->
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/responsive.css">


    <!-- Google Fonts -->
    <link href="./css/googlefont.css" rel="stylesheet">


    <!-- Favicon -->
    <link rel="shortcut icon" href="./images/favicon.png" type="image/x-icon">
    <link rel="icon" href="./images/favicon.png" type="image/x-icon">

	<!-- Font Awesome Icon Library -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


</head>

<!--
	Web Layout: Based on Bootstrap 3, Block / Float. The reason Afik chose B3 was for the stability.
	This website layout is simple and easier to manage with float. No need to use Flex or Grid.

	From this point forward, it is about making the appearance of the page according to the expected flow, and CSS.

	Reference: Bootstrap 3 Documentation
-->

<body data-spy="scroll" data-target=".navbar-default" data-offset="100" style="">

    <!-- Page Preloader -->

    <div id="loading-page" style="display: none;">
        <div id="loading-center-page" style="display: none;">
            <div id="loading-center-absolute">

                <div class="loader"></div>
            </div>
        </div>

    </div>

    <!--header-->
    <!-- Afik got inspired by W3School Bootstrap example for data-spy affix method to make the header static and change attribute when scrolling
    this is the reference link: https://www.w3schools.com/bootstrap/tryit.asp?filename=trybs_scrollspy_affix&stacked=h -->

    <div class="navbar navbar-default navbar-fixed-top affix-top" role="navigation" data-spy="affix" data-offset-top="50">

        <div class="container">

            <!--Gapo navigation & logo-->

            <div class="navbar-header">

                <button type="button" class="navbar-toggle dropdown-button waves-effect waves-teal btn-flat" data-toggle="collapse" data-target="#navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>

            </button>

				
<!--
			Comments: In the navigation section, Afik made the navigation bar background colour to alternate
				when scrolling down, and the logo colour will change (inversely)
-->
            <a class="navbar-brand logo" href="index.php">

                <img src="./images/gapo-light.png" class="logo-light" alt="" title="">
                <img src="./images/gapo-dark.png" class="logo-dark" alt="" title="">


            </a>
        </div>

        <!--Links navigation menu-->
        <div class="navbar-collapse collapse" id="navbar-collapse">
            <ul class="nav navbar-nav navbar-right navigation-links">
                <li>
                    <a data-scroll="" href="./index.php" class="section-scroll">Back to Gapo</a>
                </li>

                <li class="active-link active">
                    <a data-scroll="" href="#browse" class="section-scroll">Browse </a>
                </li>
                <li>
                    <a data-scroll="" href="#indemand" class="section-scroll">In Demand </a>
                </li>

                <li>
                    <a data-scroll="" href="#mens" class="section-scroll"> Men's </a>
                </li>
                <li>
                    <a data-scroll="" href="#womens" class="section-scroll">Women's</a>
                </li>
                <li>
                    <a data-scroll="" href="#theymove" class="section-scroll">They Move </a>
                </li>

                <li>
                    <a data-scroll="" href="#digital" class="section-scroll">Digital </a>
                </li>

                <li>
                    <a data-scroll="" href="#children" class="section-scroll">Children's</a>
                </li>


            </ul>
        </div>

    </div>

</div>
	
<!--	End of Navigation Block-->

	<!--Intro-->

<section id="home" class="intro-section">

    <div class="section-inner-intro xs-section-align sm-section-align">


        <!--container-->
        <div class="container">
            <div class="row">


                <div class="intro-section-content">
				
                    
                    <div class="col-sm-7 col-md-6 col-md-offset-1 text-inner">
						<div class="text-section">
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						
                            <h1>Let's take a look at what we have in store for you.</h1>

                            <p>If you know exactly what you are looking for, please proceed to the members' section to find what you need.</p>
                            <p>&nbsp;</p>
							<p>&nbsp;</p>   
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!--container-->
    </section>

    <!--End intro-->

    <!--browse-->

    <section id="browse" class="padd-section ">

        <!--Container // Kotak utama masukkan section atas ni. Make sure tutup bracket DIV-->

        <div class="container">
            <div class="row">
                <!-- START Section - First part call section header dan text center -->
                <div class="section-header text-center">
                    <div class="row-centered">
                        <div class="col-md-6 col-xs-12 col-sm-6 col-centered">

                            <h2 class="section-title text-center">Top Categories</h2>
                            <p>Here are the popular search results that have been tabulated for you</p>
                            </div>
                        </div>
                    </div>
                    <!-- End title-section -->

                    <!-- Start Feature 1 -->

                    <div class="col-md-4 col-sm-4 col-xs-12 wow fadeInUp" style="visibility: hidden; animation-name: none;">

                        <div class="browse-block">

                            <i class="icon-heart"></i>
                            <h3>In Demand</h3>
                            <a href="#indemand">Best Sellers | Best Debuts | Top 20 | Biographies | Business & Leadership
                              | Children's Books | Cookbooks | History | Romance | Science Fiction</a>
                            </div>


                        </div>

                        <!-- End Feature 1 -->

                        <!-- Start Feature 2 -->
                        <div class="col-md-4 col-sm-4 col-xs-12 wow fadeInUp" style="visibility: hidden; animation-name: none;">

                            <div class="browse-block">

                                <i class="icon-mustache"></i>
                                <h3>Men's</h3>
                                <a href="#mens">Sex | Self-Help | Sports & Outdoors | Business | Money | Politics
                                  | Games | Tools & Home Improvement | Men Lifestyle | Health & Style</a>

                                </div>


                            </div>

                            <!-- End Feature 2 -->
                            <!-- Start Feature 3 -->
                            <div class="col-md-4 col-sm-4 col-xs-12 wow fadeInUp" style="visibility: hidden; animation-name: none;">

                                <div class="browse-block">

                                    <i class="icon-diamond"></i>
                                    <h3>Women's</h3>
                                    <a href="#womens">Romance  | Mystery, Thriller and Crime  |  Cookbooks  |  Health & Wellness
                                      |  Religion & Spirituality  | Fantasy | Fashion  | Style  | Furniture & Decoration  | Pets</a>

                                    </div>


                                </div>
                                <!-- End Feature 3 -->
				
                                <!-- Start Feature 4 -->
                                <div class="col-md-4 col-sm-4 col-xs-12 wow fadeInUp" style="visibility: hidden; animation-name: none;">

                                    <div class="browse-block">

                                        <i class="icon-settings"></i>
                                        <h3>They Move </h3>
                                        <a href="#theymove">Repair & Maintenance  |  Motorcycles  | Trucks & Vans  |  Classic Cars  |  History  |  Driver's Education  |
                                        Buyer's Guides  |  Racing  |  Luxury  |  Insurance </a>

                                        </div>
                                    </div>
                                    <!-- End Feature 4 -->

                                    <!-- Start Feature 5 -->
                                    <div class="col-md-4 col-sm-4 col-xs-12 wow fadeInUp" style="visibility: hidden; animation-name: none;">

                                        <div class="browse-block">

                                            <i class="icon-book-open"></i>
                                            <h3>Digital</h3>
                                            <a href="#digital">Robotics  |  AI  | Digital Business  | Digital Products  | Machine Learning  | Software Engineering |  Networking  |
                                            Programming  |  UX  |  UI | NFT & Cryptos  | Digital Arts </a>

                                            </div>
                                        </div>
                                        <!-- End Feature 5 -->

                                        <!-- Start Feature 5 -->
                                        <div class="col-md-4 col-sm-4 col-xs-12 wow fadeInUp" style="visibility: hidden; animation-name: none;">

                                            <div class="browse-block">

                                                <i class="icon-note"></i>
                                                <h3>Children's</h3>
                                                <a href="#children">Picture Books  |  Easy Reader  |  Classical |  Fantasy  |  Sci-Fi  |  Toddlers </a>

                                                </div>
                                            </div>
                                            <!-- End Feature 5 -->
                                        </div>

                                    </div>
                                    <!--container-->

                                </section>

                                <!--End browse-->

                                <!--About-->


                                <section id="indemand" class="padd-section bg-color-section">


                                    <!--container-->

 <div class="container">
										                         			
    <div class="row">
    <div class="container">
		<div class="browse-block"><i class="icon-heart"></i> <h4>In Demand - Extremely Popular Titles</h4></div>
    
												
    <div id="products" class="row list-group">
        
		<div id="products1" class="row list-group">
        <div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Remarkably Bright Creatures </h4>
					<img src="https://images-na.ssl-images-amazon.com/images/I/51fMaH1tRyL._AC_SX184_.jpg" alt="Remarkably Bright Creatures: A Novel Shelby Van Pelt" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$14.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>

			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> What My Bones Know </h4>
					<img src="https://images-na.ssl-images-amazon.com/images/I/51Yp4cPzh3L._AC_SX184_.jpg" alt="What My Bones Know: A Memoir of Healing from Complex Trauma" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$13.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> All My Rage: A Novel </h4>
					<img src="https://images-na.ssl-images-amazon.com/images/I/41EcpwOA81L._AC_SX184_.jpg" alt="All My Rage: A Novel" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$10.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> The Maid: A Novel </h4>
					<img src="https://images-na.ssl-images-amazon.com/images/I/41e+bOAeE-L._AC_SX184_.jpg" alt="The Maid: A Novel" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$13.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> River of the Gods </h4>
					<img src="https://images-na.ssl-images-amazon.com/images/I/51pFNnDSdeL._AC_SX184_.jpg" alt="River of the Gods: Genius, Courage, and Betrayal in the Search for the Source of the Nile" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$14.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Lessons in Chemistry </h4>
					<img src="https://images-na.ssl-images-amazon.com/images/I/41eTiiPXcgL._AC_SX184_.jpg" alt="Lessons in Chemistry: A Novel" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$14.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
        
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Memphis: A Novel </h4>
					<img src="https://images-na.ssl-images-amazon.com/images/I/51DLm21mCwL._AC_SX184_.jpg" alt="Memphis: A Novel" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$13.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Sea of Tranquility </h4>
					<img src="https://images-na.ssl-images-amazon.com/images/I/51P+qWTnGsS._AC_SX184_.jpg" alt="Sea of Tranquility: A novel" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$11.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Half-Blown Rose </h4>
					<img src="https://images-na.ssl-images-amazon.com/images/I/51XDLGnkp8L._AC_SX184_.jpg" alt="Half-Blown Rose: A novel" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$13.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
		
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Hello, Molly!: A Memoir </h4>
					<img src="https://images-na.ssl-images-amazon.com/images/I/41xg7ewIrNL._AC_SX184_.jpg" alt="Hello Molly! A Memoir" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$14.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
	
		<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> The Kaiju Preservation </h4>
					<img src="https://images-na.ssl-images-amazon.com/images/I/51WcP+w2TDS._AC_SX184_.jpg" alt="The Kaiju Preservation Society" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$13.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
		<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Sleepwalk : A Novel </h4>
					<img src="https://images-na.ssl-images-amazon.com/images/I/510sYnD2ezS._AC_SX184_.jpg" alt="Sleepwalk: A Novel" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$14.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			
			
			
			
			
			
    </div>
</div>
</div>
										

                                        <!--container-->

                                    </div>
									
									
									</div>
                                </section>
                                <!--End In Demand-->



<section>                                <!--Details indemand Variety-->

<div class="container">
										                         			
    <div class="row">
    <div class="container">
		<div class="browse-block"><i class="icon-heart"></i> <h4>In Demand - Varieties</h4></div>
    
												
    <div id="products2" class="row list-group">
        
		<div id="products3" class="row list-group">
        <div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> A Time to Lead: Mastering</h4>
					<img src="https://m.media-amazon.com/images/I/412uld24ejL._SY346_.jpg" alt="A Time to Lead: Mastering Your Self . . . So You Can Master Your World" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$25.00</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>

			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Buy Then Build: How </h4>
					<img src="https://m.media-amazon.com/images/I/41Xxp-pGdqL._SY346_.jpg" alt="Buy Then Build: How Acquisition Entrepreneurs Outsmart the Startup Game" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$28.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> The Big Dark Sky </h4>
					<img src="https://m.media-amazon.com/images/I/51IP1vp4DbL._SY346_.jpg" alt="The Big Dark Sky" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$20.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Radical Candor: Fully Revised </h4>
					<img src="https://m.media-amazon.com/images/I/41MFKXNZVOL._SY346_.jpg" alt="Radical Candor: Fully Revised & Updated Edition: Be a Kick-Ass Boss Without Losing Your Humanity" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$25.49</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Harry Potter Sorcerer's Stone </h4>
					<img src="https://m.media-amazon.com/images/I/51Ppi-8kISL.jpg" alt="Harry Potter and the Sorcerer's Stone" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$13.49</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Harry Potter: Chamber </h4>
					<img src="https://m.media-amazon.com/images/I/510CXXt9CqL._SY346_.jpg" alt="Harry Potter and the Chamber of Secrets" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$14.16</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
        
			
			
			
    </div>
</div>
</div>
										

                                        <!--container-->

                                    </div>
									
									
									</div>
          </section>
               <!--End indemand Details-->



               <!--mens-->


<!--               <section id="mens" class="padd-section bg-color-blue ">-->
<section id="mens" class="padd-section ">
    <div class="container">
										                         			
    <div class="row">
    <div class="container">
		<div class="browse-block"><i class="icon-mustache"></i> <h4>Men's</h4></div>
   
												
    <div id="products4" class="row list-group">
        
		<div id="products5" class="row list-group">
        <div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> The Good Guy's Guide</h4>
					<img src="https://m.media-amazon.com/images/I/41Y3D56Y6uS.jpg" alt="The Good Guy's Guide to Great Sex: Because Good Guys Make the Best Lovers" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$18.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>

			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Boys & Sex: Young Men </h4>
					<img src="https://m.media-amazon.com/images/I/51Kc8tKYqIL.jpg" alt="Boys & Sex: Young Men on Hookups, Love, Porn, Consent, and Navigating the New Masculinity" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$19.26</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> The Mosquito Bowl </h4>
					<img src="https://m.media-amazon.com/images/I/41PUdXp0ZOL._SY346_.jpg" alt="The Mosquito Bowl: A Game of Life and Death in World War II" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$24.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> First Flight, Final Fall </h4>
					<img src="https://m.media-amazon.com/images/I/51FVZq7VJ4S.jpg" alt="First Flight, Final Fally" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$11.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> So Help Me Golf: Why We</h4>
					<img src="https://m.media-amazon.com/images/I/41vpu4LVhAL._SY346_.jpg" alt="So Help Me Golf: Why We Love the Game" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$18.30</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Free Your Fascia: Relieve</h4>
					<img src="https://m.media-amazon.com/images/I/41-8YZfsdlL.jpg" alt="Free Your Fascia: Relieve Pain, Boost Your Energy, Ease Anxiety and Depression, Lower Blood Pressure, and Melt Years Off Your Body with Fascia Therapy" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$12.79</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
        
			
			
			
    </div>
</div>
</div>
										

                                        <!--container-->

     </div>
									
									
	</div>
				   
				   
				   
</section>	
						
				


       




                <!--End mens-->


                <!--womens-->

                <section id="womens" class="padd-section ">


                    <!--container-->

<div class="container">
										                         			
    <div class="row">
    <div class="container">
		<div class="browse-block"><i class="icon-diamond"></i> <h4>Women's</h4></div>
   
												
    <div id="products6" class="row list-group">
        
		<div id="products7" class="row list-group">
        <div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Reminders of Him: A Novel</h4>
					<img src="https://m.media-amazon.com/images/I/41EiBLxybSL._SY346_.jpg" alt="Reminders of Him: A Novel" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$9.75</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>

			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Fractured Freedom </h4>
					<img src="https://m.media-amazon.com/images/I/51NC57VNbvL.jpg" alt="Fractured Freedom: A Brother's Best Friend Second Chance Romance" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$15.29</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> The Perfect Marriage </h4>
					<img src="https://m.media-amazon.com/images/I/41I9KUSndiL.jpg" alt="The Perfect Marriage: A Completely Gripping Psychological Suspense" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$11.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Maangchi's Big Book Korean </h4>
					<img src="https://m.media-amazon.com/images/I/51v+Ew0quAL._SX260_.jpg" alt="Maangchi's Big Book Of Korean Cooking: From Everyday Meals to Celebration Cuisine" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$17.59</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Be A Plant-Based Woman</h4>
					<img src="https://m.media-amazon.com/images/I/61y789U055L.jpg" alt="Be A Plant-Based Woman Warrior: Live Fierce, Stay Bold, Eat Delicious" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$27.00</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> The Girl Beyond the Gate</h4>
					<img src="https://m.media-amazon.com/images/I/51sA0UbCu9L._SY346_.jpg" alt="The Girl Beyond the Gate: An absolutely unputdownable and gripping psychological thriller" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$12.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
        
			
			
			
    </div>
</div>
</div>
										

                                        <!--container-->

     </div>
									
									
	</div>
</section> <!--section ends-->

	
	
                        <!--They Move -->
	

                <section id="theymove" class="padd-section ">


                    <!--container-->

<div class="container">
										                         			
    <div class="row">
    <div class="container">
		<div class="browse-block"><i class="icon-settings"></i> <h4>They Move</h4></div>
   
												
    <div id="products8" class="row list-group">
        
		<div id="products9" class="row list-group">
        <div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Full Upright and Locked</h4>
					<img src="https://images-na.ssl-images-amazon.com/images/I/41AKle2oTlL._SX342_SY445_QL70_FMwebp_.jpg" alt="Full Upright and Locked Position: The Insider's Guide to Air Travel" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$6.24</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>

			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> The Car: Rise and Fall </h4>
					<img src="https://m.media-amazon.com/images/I/41tcSnb-xRL._SY346_.jpg" alt="The Car: The Rise and Fall of the Machine that Made the Modern World" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$26.06</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> How to Fly a Plane </h4>
					<img src="https://m.media-amazon.com/images/I/41B7TF1vyJL.jpg" alt="How to Fly a Plane" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$15.00</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Space X-15 Flight </h4>
					<img src="https://m.media-amazon.com/images/I/41CznBDhr7L._SY346_.jpg" alt="At the Edge of Space: The X-15 Flight Program" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$24.95</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Elon Musk: Tesla, SpaceX</h4>
					<img src="https://m.media-amazon.com/images/I/51tw6UjHpDL._SY346_.jpg" alt="Elon Musk: Tesla, SpaceX, and the Quest for a Fantastic Future" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$15.89</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> The Lost Flight (A Capt. Roy Henry</h4>
					<img src="https://m.media-amazon.com/images/I/518Z0-qKiBL._SY346_.jpg" alt="The Lost Flight (A Capt. Roy Henry Adventure Book 2)" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$3.95</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
        
			
			
			
    </div>
</div>
</div>
										

                                        <!--container-->

     </div>
									
									
	</div>
</section> <!--section ends-->


                        <!--E-Books -->

                        <section id="digital" class="padd-section bg-color-section">


                            <!--container-->

    <div class="container">
										                         			
    <div class="row">
    <div class="container">
		<div class="browse-block"><i class="icon-book-open"></i> <h4>Digital</h4></div>
   
												
    <div id="products10" class="row list-group">
        
		<div id="products11" class="row list-group">
        <div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Digital Painting </h4>
					<img src="https://m.media-amazon.com/images/I/51TuvBQ+YLL._SX260_.jpg" alt="Beginner's Guide to Digital Painting in Procreate" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$18.69</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>

			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Digital Photography </h4>
					<img src="https://m.media-amazon.com/images/I/51o7CzicZiL._SX260_.jpg" alt="Digital Photography Complete Course: Learn Everything You Need to Know in 20 Weeks" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$26.07</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Digital Retirement </h4>
					<img src="https://m.media-amazon.com/images/I/51OvMIN7I5L._SY346_.jpg" alt="Digital Retirement: Replace Your Social Security Income In The Next 12 Months & Retire Early (Wealth With Words)" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$14.97</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Photographer’s Guide from Zero </h4>
					<img src="https://m.media-amazon.com/images/I/41VMEAlVGgL._SX260_.jpg" alt="Learning to See: A Photographer’s Guide from Zero to Your First Paid Gigs" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$20.15</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> SEO 2022: Learn search engine</h4>
					<img src="https://m.media-amazon.com/images/I/51Bp0g-f0nL._SX260_.jpg" alt="SEO 2022: Learn search engine optimization with smart internet marketing strategies" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$23.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Get To The Top Of Google</h4>
					<img src="https://m.media-amazon.com/images/I/41q6FLMhzrL._SY346_.jpg" alt="How To Get To The Top Of Google in 2022: The Plain English Guide to SEO (Digital Marketing by Exposure Ninja)" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$10.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
        
			
			
			
    </div>
</div>
</div>
										

                                        <!--container-->

     </div>
									
									
	</div>
                    </section>

                    <!--End of E-Books & Library -->


                    <!--children -->

                    <section id="children" class="padd-section padd-bottom">

                        <!--container-->
                        <div class="container">
										                         			
    <div class="row">
    <div class="container">
		<div class="browse-block"><i class="icon-note"></i> <h4>Children's</h4></div>
   
												
    <div id="products12" class="row list-group">
        
		<div id="products13" class="row list-group">
        <div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Diary of a Wimpy Kid</h4>
					<img src="https://m.media-amazon.com/images/I/51iVM82PGIL._SY346_.jpg" alt="Rodrick Rules (Diary of a Wimpy Kid, Book 2)" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$9.48</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>

			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Itsy Bitsy Spider </h4>
					<img src="https://images-na.ssl-images-amazon.com/images/I/410O4XyTXkL._SX318_BO1,204,203,200_.jpg" alt="Itsy Bitsy Spider - Children's Finger Puppet Board Book" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$8.93</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Edible Crafts Kid's Cookbook </h4>
					<img src="https://m.media-amazon.com/images/I/51GcPgsVG7L._SX260_.jpg" alt="Edible Crafts Kids' Cookbook Ages 4-8: 25 Fun Projects to Make and Eat!" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$11.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Frogs in Space: Lilly & Milly </h4>
					<img src="https://m.media-amazon.com/images/I/51An+cB72gL._SX260_.jpg" alt="Frogs in Space: Lilly & Milly Frog, Shog and Piggle in" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$10.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Kindness is my Superpower</h4>
					<img src="https://m.media-amazon.com/images/I/51xtD0gPz+L._SX260_.jpg" alt="Kindness is my Superpower: A children's Book About Empathy, Kindness and Compassion" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$15.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
			
			<div class="item  col-sm-6 col-md-2 col-lg-2">
            <div class="thumbnail">
                <div class="caption">
                    
					<h4 class="group inner list-group-item-text"> Silly Jokes for Kids</h4>
					<img src="https://m.media-amazon.com/images/I/51PXAUdIgFL._SY346_.jpg" alt="The Big Book of Silly Jokes for Kids" />                        
                  	<div class="row">
					
					 
                        <div class="col-xs-12 col-md-12">
						  <span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
                        </div>
                        <div class="col-xs-12 col-md-12">
                            <p class="lead">
                                US$15.99</p>
                        </div>
						<div class="col-xs-12 col-md-12">
                            <a class="btn btn-success" href="./preview.php">Details</a>
                        </div>
					  
                    </div>
              </div>
            </div>
        </div>
        
			
			
			
    </div>
</div>
</div>
										

                                        <!--container-->

     </div>
									
									
	</div>
                        </section>

                        <!--End children  -->

                        <!--Footer -->

                        <footer>

                            <div class="container">
                                <div class="row">

                                    <div class="footer-top">

                                        <!-- Start title-section -->
                                        

                                                 </div>

                                                 <div class="footer-bottom row-centered">
                                                    <!-- COPYRIGHT TEXT -->
													 <a href="#"> Terms of Use & PDPA</a>

                                                    <div class="copyright">
                                                        <p>2022 © Copyright www.gapo.com.my All rights Reserved.</p>
                                                    </div>
                                                    <!-- COPYRIGHT TEXT -->


                                                </div>


                                            </div>
                                        </div>

									
                                    </footer>


                                    <!--Footer -->
									


                					<script src="./js/modernizr.js"></script>
                                    <!-- Bootstrap Plugins -->
                                    <script src="./js/bootstrap.min.js"></script>                    
	

	
	
	
	
	
									
                                    
                                    <!-- Plugins -->
                                    <script src="./js/jquery.easing.js"></script>
                                    <script src="./js/wow.min.js"></script>
                                    <script src="./js/owl.carousel.min.js"></script>
                                    <script src="./js/magnific-popup.min.js"></script>
                                    <script src="./js/jquery.scrollUp.min.js"></script>
                                    <script src="./js/jquery.ajaxchimp.min.js"></script>
                                    <!-- Main js -->
                                    <script src="./js/main.js"></script>
	
									


									<script>
										//new items carousel - Afik Added here last minute
										$(document).ready(function(){
										$('.owl-carousel').owlCarousel({
											loop:true,
											margin:10,
											nav:false,
											responsive:{
											0:{
											items:1
											},
											600:{
											items:3
											},
											1000:{
											items:5
											}
										}
										})
										});
									</script>                  
	
	
	
		<a id="scrollUp" href="#top" style="display: none; position: fixed; z-index: 2147483647;">
		<i class="icon-arrow-up"></i></a>
		
</body>
</html>
