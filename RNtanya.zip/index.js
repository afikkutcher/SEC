import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import SplashScreen from './src/screens/SplashScreen';
import GoogleSigninScreen from './src/screens/GoogleSigninScreen';
import MainMenuScreen from './src/screens/MainMenuScreen';
import TakeNewOrderScreen from './src/screens/TakeNewOrderScreen';
import ReviewPastOrdersScreen from './src/screens/ReviewPastOrdersScreen';
import KitchenConfirmationScreen from './src/screens/KitchenConfirmationScreen';
import SummaryOfOrdersScreen from './src/screens/SummaryOfOrdersScreen';
import CashierScreen from './src/screens/CashierScreen';
import FoodInventoryScreen from './src/screens/FoodInventoryScreen';

const MainStack = createStackNavigator();
const OrderStack = createStackNavigator();

function MainStackScreen() {
    return (
        <MainStack.Navigator>
            <MainStack.Screen name="MainMenu" component={MainMenuScreen} />
            <MainStack.Screen name="FoodInventory" component={FoodInventoryScreen} />
        </MainStack.Navigator>
    );
}

function OrderStackScreen() {
    return (
        <OrderStack.Navigator>
            <OrderStack.Screen name="TakeNewOrder" component={TakeNewOrderScreen} />
            <OrderStack.Screen
                name="ReviewPastOrders"
                component={ReviewPastOrdersScreen}
            />
            <OrderStack.Screen
                name="KitchenConfirmation"
                component={KitchenConfirmationScreen}
            />
            <OrderStack.Screen
                name="SummaryOfOrders"
                component={SummaryOfOrdersScreen}
            />
            <OrderStack.Screen name="Cashier" component={CashierScreen} />
        </OrderStack.Navigator>
    );
}

function App() {
    return (
        <NavigationContainer>
            <MainStackScreen />
            <OrderStackScreen />
        </NavigationContainer>
    );
}

export default App;
