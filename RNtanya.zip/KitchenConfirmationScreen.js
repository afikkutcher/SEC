import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, Button } from 'react-native';
import { useFirebase } from 'react-redux-firebase';
import { useNavigation } from '@react-navigation/native';

// Screen for reviewing new orders and preparing them
function KitchenConfirmationScreen() {
    const firebase = useFirebase();
    const navigation = useNavigation();
    const [orders, setOrders] = useState([]);

    useEffect(() => {
        // Fetch orders from Firebase database
        const unsubscribe = firebase.on('value', (snapshot) => {
            const ordersData = snapshot.val();
            const orders = Object.keys(ordersData).map((key) => ({
                ...ordersData[key],
                id: key,
            }));
            setOrders(orders);
        });
        return () => {
            unsubscribe();
        };
    }, [firebase]);

    async function handlePreparingOrder(id) {
        try {
            // Update order status to "preparing"
            await firebase.update(`/orders/${id}`, { status: 'preparing' });
        } catch (error) {
            console.error(error);
        }
    }

    async function handleOrderReady(id) {
        try {
            // Update order status to "ready"
            await firebase.update(`/orders/${id}`, { status: 'ready' });
            // Send notification to original order and cashier
            // TODO: implement notification logic
        } catch (error) {
            console.error(error);
        }
    }

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Kitchen Confirmation</Text>
            <FlatList
                data={orders}
                renderItem={({ item }) => (
                    <View style={styles.itemContainer}>
                        <Text>{item.order}</Text>
                        {item.status === 'new' && (
                            <Button
                                title="Preparing Order"
                                onPress={() => handlePreparingOrder(item.id)}
                            />
                        )}
                        {item.status === 'preparing' && (
                            <Button
                                title="Order is Ready"
                                onPress={() => handleOrderReady(item.id)}
                            />
                        )}
                    </View>
                )}
                keyExtractor={(item) => item.id}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
    },
    itemContainer: {
        width: '80%',
        borderBottomWidth: 1,
        padding: 10,
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
});