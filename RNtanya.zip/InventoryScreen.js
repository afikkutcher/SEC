import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, Button, Image, TextInput } from 'react-native';
import { useFirebase } from 'react-redux-firebase';
import { useNavigation } from '@react-navigation/native';

// Screen for managing food and beverage inventory
function InventoryScreen() {
    const firebase = useFirebase();
    const navigation = useNavigation();
    const [items, setItems] = useState([]);
    const [formVisible, setFormVisible] = useState(false);
    const [formType, setFormType] = useState('');
    const [formData, setFormData] = useState({
        title: '',
        price: '',
        imageUrl: '',
    });

    useEffect(() => {
        // Fetch items from Firebase database
        const unsubscribe = firebase.on('value', (snapshot) => {
            const itemsData = snapshot.val();
            const items = Object.keys(itemsData).map((key) => ({
                ...itemsData[key],
                id: key,
            }));
            setItems(items);
        });
        return () => {
            unsubscribe();
        };
    }, [firebase]);

    function handleFormChange(name, value) {
        setFormData({
            ...formData,
            [name]: value,
        });
    }

    async function handleAddItem() {
        try {
            // Add item to Firebase database
            await firebase.push('/items', formData);
            setFormVisible(false);
            setFormData({
                title: '',
                price: '',
                imageUrl: '',
            });
        } catch (error) {
            console.error(error);
        }
    }

    async function handleEditItem(id) {
        try {
            // Update item in Firebase database
            await firebase.update(`/items/${id}`, formData);
            setFormVisible(false);
            setFormData({
                title: '',
                price: '',
                imageUrl: '',
            });
        } catch (error) {
            console.error(error);
        }
    }

    async function handleDeleteItem(id) {
        try {
            // Delete item from Firebase database
            await firebase.remove(`/items/${id}`);
        } catch (error) {
            console.error(error);
        }
    }

    function renderForm() {
        return (
            <View style={styles.formContainer}>
                <TextInput
                    style={styles.formInput}
                    placeholder="Title"
                    value={formData.title}
                    onChangeText={(text) => handleFormChange('title', text)}
                />
                <TextInput
                    style={styles.formInput}
                    placeholder="Price"
                    value={formData.price}
                    onChangeText={(text) => handleFormChange('price', text)}
