//Author: Afik Yusof  24 December 2022
//Supervisor: Norma LO (SEC - Adnexio)
//Alternative Project - Mobile App
//Project Description: This is an alternative React-Native project created for submission
//and assessment purposes, to see the skills required to create a mobile app.
//Explanation: There was a serious issue with the ReactNative system that continuously creating
//deprecated files, libraries and extensions during the author's attempt to create a project with redux and firebase.
//This alteranative project is a game that allows user to train ESP as per published research.
//The author has completed ES6 certification and the whole program is created through coding in JS.

import React, { useState } from 'react';
import { View, Text, Button, Animated } from 'react-native';
import Sound from 'react-native-sound';
import type {Node} from 'react';
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  useColorScheme,
  } from 'react-native';
  

  
  const App = () => {
    const [leftButton, setLeftButton] = useState(Math.random() < 0.5);
    const [rightButton, setRightButton] = useState(Math.random() < 0.5);
    const [result, setResult] = useState(null);
    const [score, setScore] = useState(0);
    const [numCycles, setNumCycles] = useState(0);
    const [resultScale, setResultScale] = useState(new Animated.Value(1));
    const [chimeSound] = useState(new Sound('chime.mp3', Sound.MAIN_BUNDLE, (error) => {
      if (error) {
        console.log(error);
      }
    }));
    const [warningSound] = useState(new Sound('warning.mp3', Sound.MAIN_BUNDLE, (error) => {
      if (error) {
        console.log(error);
      }
    }));
  
    const handleLeftButtonPress = () => {
      if (leftButton) {
        setScore(score + 1);
        chimeSound.play();
      } else {
        warningSound.play();
      }
      setResult(leftButton ? 'TRUE' : 'FALSE');
      setNumCycles(numCycles + 1);
      animateResult();
    };
  
    const handleRightButtonPress = () => {
      if (rightButton) {
        setScore(score + 1);
        chimeSound.play();
      } else {
        warningSound.play();
      }
      setResult(rightButton ? 'TRUE' : 'FALSE');
      setNumCycles(numCycles + 1);
      animateResult();
    };
  
    const handleResetPress = () => {
      setLeftButton(Math.random() < 0.5);
      setRightButton(Math.random() < 0.5);
      setResult(null);
      setScore(0);
      setNumCycles(0);
    };
  
    const animateResult = () => {
      Animated.sequence([
        Animated.timing(resultScale, { toValue: 1.5, duration: 200, useNativeDriver: true }),
        Animated.timing(resultScale, { toValue: 1, duration: 200, useNativeDriver: true }),
      ]).start();
    };
  
    if (numCycles === 10) {
      return (
        <View style={{ backgroundColor: 'white', flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ textAlign: 'center', fontSize: 24, fontWeight: 'bold' }}>
          Game Over! Your score is {score}
        </Text>
        <Text style={{ textAlign: 'center', marginTop: 10, fontWeight: 'bold' }}>
          You chose TRUE {score} times and FALSE {10 - score} times
        </Text>
        <View style={{ alignItems: 'center', marginTop: 20 }}>
          <Button title="Reset" onPress={handleResetPress} style={{ width: 100 }} />
        </View>
      </View>
    );
  }

  return (
    <View style={{ backgroundColor: 'white', flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <View style={{ marginTop: 50 }}>
        <Text style={{ textAlign: 'center', fontSize: 24, fontWeight: 'bold' }}>ESP TRAINER</Text>
        <Text style={{ textAlign: 'center', marginTop: 10, fontWeight: 'bold' }}>
          How strong is your intuition?
        </Text>
      </View>
      <Text style={{ textAlign: 'center', marginTop: 20, fontSize: 18 }}>
        You have {10 - numCycles} chances.
      </Text>
      <Text style={{ textAlign: 'center', marginTop: 20, marginRight: 20, marginLeft: 20, fontSize: 18 }}>
        Focus, and relax. Below are two buttons. One of the buttons is TRUE while the other is FALSE. Now take a deep breath and choose the right button that will display TRUE
      </Text>
      <View style={{ flexDirection: 'row', marginTop: 20, alignSelf: 'center' }}>
        <Button
          title="LEFT"
          color="#0000FF"
          onPress={handleLeftButtonPress}
          style={{ width: 100, height: 100 }}
        />
        <View style={{ width: 20 }} />
        <Button
          title="RIGHT"
          color="#FFFF00"
          onPress={handleRightButtonPress}
          style={{ width: 100, height: 100 }}
        />
      </View>
      {result !== null && (
        <Animated.Text
          style={{ textAlign: 'center', marginTop: 20, fontSize: 18, transform: [{ scale: resultScale }] }}
        >
          {result}
        </Animated.Text>
      )}
      <View style={{ alignItems: 'center', marginTop: 20 }}>
        <Button
          title="Reset"
          onPress={handleResetPress}
          style={{ width: 100 }}
        />
      </View>
    </View>
  );
};

export default App;

  