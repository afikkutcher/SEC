import React from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';
import { useFirebase } from 'react-redux-firebase';

// Google Signin screen using RN Firebase
function GoogleSigninScreen() {
    const firebase = useFirebase();

    async function handleGoogleSignin() {
        try {
            await firebase.login({ provider: 'google', type: 'popup' });
            // Navigate to main menu screen after successful signin
            navigation.navigate('MainMenu');
        } catch (error) {
            console.error(error);
        }
    }

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Table Order</Text>
            <Button title="Sign in with Google" onPress={handleGoogleSignin} />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
    },
});

export default GoogleSigninScreen;
