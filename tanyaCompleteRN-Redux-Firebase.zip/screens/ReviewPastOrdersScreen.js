import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, Button } from 'react-native';
import { useFirebase } from 'react-redux-firebase';
import { useNavigation } from '@react-navigation/native';

// Screen for listing past orders and allowing user to edit or delete any order
function ReviewPastOrdersScreen() {
    const firebase = useFirebase();
    const navigation = useNavigation();
    const [orders, setOrders] = useState([]);

    useEffect(() => {
        // Fetch orders from Firebase database
        const unsubscribe = firebase.on('value', (snapshot) => {
            const ordersData = snapshot.val();
            const orders = Object.keys(ordersData).map((key) => ({
                ...ordersData[key],
                id: key,
            }));
            setOrders(orders);
        });
        return () => {
            unsubscribe();
        };
    }, [firebase]);

    async function handleEditOrder(id) {
        try {
            // Navigate to take new order screen with order data pre-filled
            const order = orders.find((order) => order.id === id);
            navigation.navigate('TakeNewOrder', { order });
        } catch (error) {
            console.error(error);
        }
    }

    async function handleDeleteOrder(id) {
        try {
            // Delete order from Firebase database
            await firebase.remove(`/orders/${id}`);
        } catch (error) {
            console.error(error);
        }
    }

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Review Past Orders</Text>
            <FlatList
                data={orders}
                renderItem={({ item }) => (
                    <View style={styles.itemContainer}>
                        <Text>{item.order}</Text>
                        <View style={styles.buttonsContainer}>
                            <Button
                                title="Edit"
                                onPress={() => handleEditOrder(item.id)}
                            />
                            <Button
                                title="Delete"
                                onPress={() => handleDeleteOrder(item.id)}
                            />
                        </View>
                    </View>
                )}
                keyExtractor={(item) => item.id}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
    },
    itemContainer: {
        width: '80%',
        borderBottomWidth: 1,
        padding: 10,
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
});
export default ReviewPastOrdersScreen;