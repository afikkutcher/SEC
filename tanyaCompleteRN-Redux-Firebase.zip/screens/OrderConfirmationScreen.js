import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';
import { useFirebase } from 'react-redux-firebase';
import { useNavigation } from '@react-navigation/native';

// Screen for confirming and paying for an order
function OrderConfirmationScreen({ route }) {
    const firebase = useFirebase();
    const navigation = useNavigation();
    const [order, setOrder] = useState({});

    useEffect(() => {
        // Fetch order from Firebase database
        const unsubscribe = firebase.on('value', (snapshot) => {
            const ordersData = snapshot.val();
            const order = ordersData[route.params.orderId];
            setOrder(order);
        });
        return () => {
            unsubscribe();
        };
    }, [firebase, route.params.orderId]);

    async function handleOrderPayment() {
        try {
            // Update order status to "paid" in Firebase database
            await firebase.update(`/orders/${route.params.orderId}`, { status: 'paid' });
            navigation.goBack();
        } catch (error) {
            console.error(error);
        }
    }

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Order Confirmation</Text>
            <Text style={styles.subtitle}>Items:</Text>
            {order.items &&
                order.items.map((item) => (
                    <Text style={styles.item} key={item}>
                        {item}
                    </Text>
                ))}
            <Text style={styles.subtitle}>Total: {order.total}</Text>
            <Button title="Confirm Order and Pay" onPress={handleOrderPayment} />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
        backgroundColor: '#fff',
    },
    title: {
        fontSize: 32,
        fontWeight: 'bold',
        textAlign: 'center',
        marginVertical: 16,
    },
    subtitle: {
        fontSize: 24,
        fontWeight: 'bold',
        marginVertical: 8,
    },
    item: {
        fontSize: 16,
        marginVertical: 4,
    },
});

export default OrderConfirmationScreen;
