import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, Button, Image, TextInput } from 'react-native';
import { useFirebase } from 'react-redux-firebase';
import { useNavigation } from '@react-navigation/native';

// Screen for managing food and beverage inventory
function InventoryScreen() {
    const firebase = useFirebase();
    const navigation = useNavigation();
    const [items, setItems] = useState([]);
    const [formVisible, setFormVisible] = useState(false);
    const [formType, setFormType] = useState('');
    const [formData, setFormData] = useState({
        title: '',
        price: '',
        imageUrl: '',
    });

    useEffect(() => {
        // Fetch items from Firebase database
        const unsubscribe = firebase.on('value', (snapshot) => {
            const itemsData = snapshot.val();
            const items = Object.keys(itemsData).map((key) => ({
                ...itemsData[key],
                id: key,
            }));
            setItems(items);
        });
        return () => {
            unsubscribe();
        };
    }, [firebase]);

    function handleFormChange(name, value) {
        setFormData({
            ...formData,
            [name]: value,
        });
    }

    async function handleAddItem() {
        try {
            // Add item to Firebase database
            await firebase.push('/items', formData);
            setFormVisible(false);
            setFormData({
                title: '',
                price: '',
                imageUrl: '',
            });
        } catch (error) {
            console.error(error);
        }
    }

    async function handleEditItem(id) {
        try {
            // Update item in Firebase database
            await firebase.update(`/items/${id}`, formData);
            setFormVisible(false);
            setFormData({
                title: '',
                price: '',
                imageUrl: '',
            });
        } catch (error) {
            console.error(error);
        }
    }

    async function handleDeleteItem(id) {
        try {
            // Delete item from Firebase database
            await firebase.remove(`/items/${id}`);
        } catch (error) {
            console.error(error);
        }
    }

    function renderForm() {
        return (
            <View style={styles.formContainer}>
                <TextInput
                    style={styles.formInput}
                    placeholder="Title"
                    value={formData.title}
                    onChangeText={(text) => handleFormChange('title', text)}
                />
                <TextInput
                    style={styles.formInput}
                    placeholder="Price"
                    value={formData.price}
                    onChangeText={(text) => handleFormChange('price', text)}
                    keyboardType="numeric"
                />
                <TextInput
                    style={styles.formInput}
                    placeholder="Image URL"
                    value={formData.imageUrl}
                    onChangeText={(text) => handleFormChange('imageUrl', text)}
                />
                {formType === 'add' && (
                    <Button title="Add Item" onPress={handleAddItem} />
                )}
                {formType === 'edit' && (
                    <Button title="Save Changes" onPress={handleEditItem} />
                )}
            </View>
        );
    }

    function renderItem(item) {
        return (
            <View style={styles.itemContainer}>
                <Image style={styles.itemImage} source={{ uri: item.imageUrl }} />
                <View style={styles.itemInfo}>
                    <Text style={styles.itemTitle}>{item.title}</Text>
                    <Text style={styles.itemPrice}>{item.price}</Text>
                </View>
                <View style={styles.itemActions}>
                    <Button
                        title="Edit"
                        onPress={() => {
                            setFormType('edit');
                            setFormVisible(true);
                            setFormData(item);
                        }}
                    />
                    <Button
                        title="Delete"
                        onPress={() => handleDeleteItem(item.id)}
                        color="#ff0000"
                    />
                </View>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Inventory</Text>
            <Button
                title="Add Item"
                onPress={() => {
                    setFormType('add');
                    setFormVisible(true);
                    setFormData({
                        title: '',
                        price: '',
                        imageUrl: '',
                    });
                }}
            />
            {formVisible && renderForm()}
            <FlatList
                data={items}
                renderItem={({ item }) => renderItem(item)}
                keyExtractor={(item) => item.id}
                style={styles.list}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
        backgroundColor: '#fff',
    },
    title: {
        fontSize: 32,
        fontWeight: 'bold',
        textAlign: 'center',
        marginVertical: 16,
    },
    formContainer: {
        marginBottom: 16,
    },
    formInput: {
        borderWidth: 1,
        borderColor: '#ccc',
        padding: 8,
        marginBottom: 8,
    },
    list: {
        marginTop: 16,
    },
    itemContainer: {
        borderBottomWidth: 1,
        borderColor: '#ccc',
        padding: 16,
    },
    itemImage: {
        width: 64,
        height: 64,
        borderRadius: 32,
    },
    itemInfo: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'space-around',
    },
    itemTitle: {
        fontSize: 24,
        fontWeight: 'bold',
    },
    itemPrice: {
        fontSize: 16,
    },
    itemActions: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
    },
});

export default InventoryScreen;
