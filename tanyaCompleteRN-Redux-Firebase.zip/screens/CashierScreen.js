import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, Button } from 'react-native';
import { useFirebase } from 'react-redux-firebase';

// Screen for cashier to review orders that are ready to be paid
function CashierScreen() {
    const firebase = useFirebase();
    const [orders, setOrders] = useState([]);

    useEffect(() => {
        // Fetch orders from Firebase database
        const unsubscribe = firebase.on('value', (snapshot) => {
            const ordersData = snapshot.val();
            const orders = Object.keys(ordersData)
                .map((key) => ({
                    ...ordersData[key],
                    id: key,
                }))
                .filter((order) => order.status === 'ready');
            setOrders(orders);
        });
        return () => {
            unsubscribe();
        };
    }, [firebase]);

    async function handleOrderPayment(id) {
        try {
            // Update order status to "paid" in Firebase database
            await firebase.update(`/orders/${id}`, { status: 'paid' });
        } catch (error) {
            console.error(error);
        }
    }

    function renderItem(item) {
        return (
            <View style={styles.itemContainer}>
                <Text style={styles.itemTitle}>{item.total}</Text>
                {item.status === 'ready' && (
                    <Button title="Mark as Paid" onPress={() => handleOrderPayment(item.id)} />
                )}
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Cashier</Text>
            <FlatList
                data={orders}
                renderItem={({ item }) => renderItem(item)}
                keyExtractor={(item) => item.id}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
        backgroundColor: '#fff',
    },
    title: {
        fontSize: 32,
        fontWeight: 'bold',
        textAlign: 'center',
        marginVertical: 16,
    },
    itemContainer: {
        borderBottomWidth: 1,
        borderColor: '#ccc',
        padding: 16,
    },
    itemTitle: {
        fontSize: 24,
        fontWeight: 'bold',
    },
});

export default CashierScreen;
