import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, Button } from 'react-native';
import { useFirebase } from 'react-redux-firebase';
import { useNavigation } from '@react-navigation/native';

// Screen for reviewing and confirming orders from the kitchen
function KitchenConfirmationScreen() {
    const firebase = useFirebase();
    const navigation = useNavigation();
    const [orders, setOrders] = useState([]);

    useEffect(() => {
        // Fetch orders from Firebase database
        const unsubscribe = firebase.on('value', (snapshot) => {
            const ordersData = snapshot.val();
            const orders = Object.keys(ordersData).map((key) => ({
                ...ordersData[key],
                id: key,
            }));
            setOrders(orders);
        });
        return () => {
            unsubscribe();
        };
    }, [firebase]);

    async function handleOrderPreparation(id) {
        try {
            // Update order status to "preparing" in Firebase database
            await firebase.update(`/orders/${id}`, { status: 'preparing' });
        } catch (error) {
            console.error(error);
        }
    }

    async function handleOrderReady(id) {
        try {
            // Update order status to "ready" in Firebase database
            await firebase.update(`/orders/${id}`, { status: 'ready' });
        } catch (error) {
            console.error(error);
        }
    }

    function renderItem(item) {
        return (
            <View style={styles.itemContainer}>
                <Text style={styles.itemTitle}>Order #{item.id}</Text>
                <Text style={styles.itemDetails}>
                    {item.items.join(', ')} - {item.total}
                </Text>
                {item.status === 'pending' && (
                    <Button
                        title="Preparing Order"
                        onPress={() => handleOrderPreparation(item.id)}
                    />
                )}
                {item.status === 'preparing' && (
                    <Button
                        title="Order is Ready"
                        onPress={() => handleOrderReady(item.id)}
                    />
                )}
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Kitchen Confirmation</Text>
            <FlatList
                data={orders}
                renderItem={({ item }) => (
                    <View style={styles.itemContainer}>
                        <Text>{item.id}</Text>
                        <FlatList
                            data={item.items}
                            renderItem={({ item }) => <Text>{item}</Text>}
                            keyExtractor={(item, index) => index.toString()}
                        />

                        <Text>{item.total}</Text>
                        {item.status === 'pending' && (
                            <Button
                                title="Preparing Order"
                                onPress={() => handleOrderPreparation(item.id)}
                            />
                        )}
                        {item.status === 'preparing' && (
                            <Button
                                title="Order is Ready"
                                onPress={() => handleOrderReady(item.id)}
                            />
                        )}
                    </View>
                )}
                keyExtractor={(item) => item.id}
            />
            <Button title="Back to Main Menu" onPress={() => navigation.goBack()} />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
        backgroundColor: '#fff',
    },
    title: {
        fontSize: 32,
        fontWeight: 'bold',
        textAlign: 'center',
        marginVertical: 16,
    },
    itemContainer: {
        borderBottomWidth: 1,
        borderColor: '#ccc',
        padding: 16,
    },
    itemTitle: {
        fontSize: 24,
        fontWeight: 'bold',
    },
    itemDetails: {
        fontSize: 16,
    },
});

export default KitchenConfirmationScreen;
