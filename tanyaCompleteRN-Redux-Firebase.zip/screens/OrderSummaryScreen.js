import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';
import { useFirebase } from 'react-redux-firebase';

// Screen for reviewing order summary by date
function OrderSummaryScreen() {
    const firebase = useFirebase();
    const [orders, setOrders] = useState([]);

    useEffect(() => {
        // Fetch orders from Firebase database
        const unsubscribe = firebase.on('value', (snapshot) => {
            const ordersData = snapshot.val();
            const orders = Object.keys(ordersData).map((key) => ({
                ...ordersData[key],
                id: key,
            }));
            setOrders(orders);
        });
        return () => {
            unsubscribe();
        };
    }, [firebase]);

    function renderItem(item) {
        return (
            <View style={styles.itemContainer}>
                <Text style={styles.itemTitle}>{item.date}</Text>
                <Text style={styles.itemDetails}>
                    {item.items.join(', ')} - {item.total}
                </Text>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Order Summary</Text>
            <FlatList
                data={orders}
                renderItem={({ item }) => renderItem(item)}
                keyExtractor={(item) => item.id}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
        backgroundColor: '#fff',
    },
    title: {
        fontSize: 32,
        fontWeight: 'bold',
        textAlign: 'center',
        marginVertical: 16,
    },
    itemContainer: {
        borderBottomWidth: 1,
        borderColor: '#ccc',
        padding: 16,
    },
    itemTitle: {
        fontSize: 24,
        fontWeight: 'bold',
    },
    itemDetails: {
        fontSize: 16,
    },
});

export default OrderSummaryScreen;
