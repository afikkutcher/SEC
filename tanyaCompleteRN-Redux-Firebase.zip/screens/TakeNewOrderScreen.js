import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, Button } from 'react-native';
import { useFirebase } from 'react-redux-firebase';
import { useNavigation } from '@react-navigation/native';

// Screen for taking input from customer and saving data in Firebase database
function TakeNewOrderScreen() {
    const firebase = useFirebase();
    const navigation = useNavigation();
    const [order, setOrder] = useState('');

    async function handleSaveOrder() {
        try {
            // Save order to Firebase database
            await firebase.push('/orders', { order });
            // Navigate to review past orders screen after successful save
            navigation.navigate('ReviewPastOrders');
        } catch (error) {
            console.error(error);
        }
    }

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Take New Order</Text>
            <TextInput
                style={styles.input}
                placeholder="Enter order details"
                value={order}
                onChangeText={setOrder}
            />
            <Button title="Save Order" onPress={handleSaveOrder} />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
    },
    input: {
        width: '80%',
        height: 40,
        borderColor: 'gray',
        borderWidth: 1,
        marginVertical: 10,
        padding: 10,
    },
});

export default TakeNewOrderScreen;
