import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

// Splash screen with title and subtitle
function SplashScreen() {
    return (
        <View style={styles.container}>
            <Text style={styles.title}>Ambil Order</Text>
            <Text style={styles.subtitle}>Ver 1 - SEC Project Adnexio NLO by Afik</Text>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
    },
    subtitle: {
        fontSize: 16,
        color: 'gray',
    },
});

export default SplashScreen;
