import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import SplashScreen from './screens/SplashScreen';
import GoogleSignInScreen from './screens/GoogleSigninScreen';
import MainMenuScreen from './screens/MainMenuScreen';
import TakeNewOrderScreen from './screens/TakeNewOrderScreen';
import ReviewPastOrdersScreen from './screens/ReviewPastOrdersScreen';
import OrderConfirmationScreen from './screens/OrderConfirmationScreen';
import KitchenConfirmationScreen from './screens/KitchenConfirmationScreen';
import OrderSummaryScreen from './screens/OrderSummaryScreen';
import CashierScreen from './screens/CashierScreen';
import InventoryScreen from './screens/InventoryScreen';

const Stack = createStackNavigator();

function App() {
    return (
        <NavigationContainer>
            <Stack.Navigator initialRouteName="Splash">
                <Stack.Screen name="Splash" component={SplashScreen} options={{ headerShown: false }} />
                <Stack.Screen name="SignIn" component={GoogleSignInScreen} options={{ headerShown: false }} />
                <Stack.Screen name="MainMenu" component={MainMenuScreen} options={{ headerShown: false }} />
                <Stack.Screen name="TakeNewOrder" component={TakeNewOrderScreen} options={{ headerShown: false }} />
                <Stack.Screen name="ReviewPastOrders" component={ReviewPastOrdersScreen} options={{ headerShown: false }} />
                <Stack.Screen name="OrderConfirmation" component={OrderConfirmationScreen} options={{ headerShown: false }} />
                <Stack.Screen name="KitchenConfirmation" component={KitchenConfirmationScreen} options={{ headerShown: false }} />
                <Stack.Screen name="OrderSummary" component={OrderSummaryScreen} options={{ headerShown: false }} />
                <Stack.Screen name="Cashier" component={CashierScreen} options={{ headerShown: false }} />
                <Stack.Screen name="Inventory" component={InventoryScreen} options={{ headerShown: false }} />
            </Stack.Navigator>
        </NavigationContainer>
    );
}

export default App;
